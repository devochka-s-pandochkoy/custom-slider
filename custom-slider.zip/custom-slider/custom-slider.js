document.addEventListener('DOMContentLoaded', function() {
    // Проверяем ширину экрана
    if (window.innerWidth >= 768) {
        const slides = document.querySelectorAll('.custom-slider .slide');
        const prevButton = document.querySelector('.custom-slider .slider-prev');
        const nextButton = document.querySelector('.custom-slider .slider-next');
        let currentSlide = 0;

        function showSlide(index) {
            slides.forEach((slide, i) => {
                slide.style.display = i === index ? 'block' : 'none';
            });
        }

        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }

        function prevSlide() {
            currentSlide = (currentSlide - 1 + slides.length) % slides.length;
            showSlide(currentSlide);
        }

        // Автоматическое переключение слайдов
        const interval = sliderSettings.interval; // Получаем интервал из переданных данных
        let autoSlideInterval = setInterval(nextSlide, interval);

        // Обработчики для кнопок "Вперёд" и "Назад"
        nextButton.addEventListener('click', () => {
            clearInterval(autoSlideInterval); // Останавливаем автоматическое переключение
            nextSlide();
            autoSlideInterval = setInterval(nextSlide, interval); // Запускаем снова
        });

        prevButton.addEventListener('click', () => {
            clearInterval(autoSlideInterval); // Останавливаем автоматическое переключение
            prevSlide();
            autoSlideInterval = setInterval(nextSlide, interval); // Запускаем снова
        });
    }
});