<?php
/*
Plugin Name: Galo Slider
Plugin URI: https://github.com/devochka-s-pandochkoy/custom-slider
Description: Плагин для создания слайдера с возможностью управления из админки WordPress.
Version: 1.0.0
Author: devochka-s-pandochkoy
Author URI: https://github.com/devochka-s-pandochkoy
Tested up to: 6.7.2
Requires PHP: 7.4
License: GNU General Public License v2 or later
License URI: LICENSE
*/

// Регистрируем Custom Post Type для слайдов
function custom_slider_post_type() {
    register_post_type('slider',
        array(
            'labels' => array(
                'name' => __('Слайдер'),
                'singular_name' => __('Слайд')
            ),
            'public' => true,
            'has_archive' => false,
            'supports' => array('title', 'thumbnail', 'editor'), // Добавляем поддержку редактора
            'menu_icon' => 'dashicons-images-alt2', // Иконка в админке
        )
    );
}
add_action('init', 'custom_slider_post_type');

// Добавляем страницу настроек плагина
function custom_slider_settings_page() {
    add_menu_page(
        'Настройки слайдера', // Заголовок страницы
        'Настройки Слайдера', // Название в меню
        'manage_options', // Права доступа
        'custom-slider-settings', // Slug страницы
        'custom_slider_settings_page_html', // Функция для вывода HTML
        'dashicons-slides', // Иконка
        100 // Позиция в меню
    );
}
add_action('admin_menu', 'custom_slider_settings_page');

// HTML для страницы настроек
function custom_slider_settings_page_html() {
    // Проверяем права доступа
    if (!current_user_can('manage_options')) {
        return;
    }

    // Сохраняем настройки, если форма отправлена
    if (isset($_POST['custom_slider_interval'])) {
        update_option('custom_slider_interval', sanitize_text_field($_POST['custom_slider_interval']));
        echo '<div class="notice notice-success"><p>Настройки сохранены!</p></div>';
    }

    // Получаем текущее значение интервала
    $interval = get_option('custom_slider_interval', 5000); // По умолчанию 5000 мс (5 секунд)
    ?>
    <div class="wrap">
        <h1>Настройки слайдера</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="custom_slider_interval">Интервал переключения слайдов (в миллисекундах):</label></th>
                    <td>
                        <input name="custom_slider_interval" type="number" id="custom_slider_interval" value="<?php echo esc_attr($interval); ?>" class="regular-text" min="1">
                        <p class="description">Укажите время в миллисекундах (1000 мс = 1 секунда).</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Сохранить изменения'); ?>
        </form>
    </div>
    <?php
}


// Функция для вывода слайдера
function display_custom_slider() {
    // Не выводим слайдер на мобильных устройствах
    if (wp_is_mobile()) {
        return;
    }

    $slider_query = new WP_Query(array(
        'post_type' => 'slider',
        'posts_per_page' => -1,
    ));

    if ($slider_query->have_posts()) :
        echo '<div class="custom-slider">';
        while ($slider_query->have_posts()) : $slider_query->the_post();
            if (has_post_thumbnail()) :
                echo '<div class="slide">';
                the_post_thumbnail('full');

                // Добавляем контейнер для текста
                echo '<div class="slide-content">';
                the_content(); // Выводим текст слайда
                echo '</div>';

                echo '</div>';
            endif;
        endwhile;

        // Добавляем кнопки "Вперёд" и "Назад"
        echo '<button class="slider-prev">‹</button>';
        echo '<button class="slider-next">›</button>';

        echo '</div>';
    endif;
    wp_reset_postdata();
}

// Создаем шорткод для вывода слайдера
function custom_slider_shortcode() {
    ob_start(); // Буферизация вывода
    display_custom_slider();
    return ob_get_clean();
}
add_shortcode('custom_slider', 'custom_slider_shortcode');

// Подключаем стили и скрипты
function custom_slider_scripts() {
    if (!wp_is_mobile()) {
        wp_enqueue_style('custom-slider-style', plugins_url('custom-slider.css', __FILE__));

        // Передаем интервал из настроек в JavaScript
        $interval = get_option('custom_slider_interval', 5000); // По умолчанию 5000 мс (5 секунд)
        wp_enqueue_script('custom-slider-script', plugins_url('custom-slider.js', __FILE__), array(), null, true);
        wp_localize_script('custom-slider-script', 'sliderSettings', array(
            'interval' => $interval, // Передаем интервал в JavaScript
        ));
    }
}

add_action('wp_enqueue_scripts', 'custom_slider_scripts');